#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QSortFilterProxyModel>
#include <QTextTableFormat>
#include <QStandardItemModel>
#include <QDialog>
#include <QFileDialog>
#include <QMediaPlayer>
#include <QDialog>
#include <QDesktopWidget>
#include <QSettings>
#include <QTextStream>
#include <QFile>
#include <QDataStream>
#include "reclamation.h"
#include "smtp.h"
#include <QPrinter>
#include "arduino.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pb_ajouter_clicked();
   void on_pb_modifier_clicked();

    void on_pb_supprimer_clicked();

    void on_pb_play_vid_clicked();

    void on_pb_stop_vid_clicked();

    void browse();







    void update_label();





    
    void on_button_trier_clicked();

    void on_pdf_clicked();

    void on_image_clicked();

    void on_radioButton_clicked();

    void on_stat_clicked();

    void on_recherche_textChanged();

private:
    QMediaPlayer* player;
    QVideoWidget* vw;
    Ui::MainWindow *ui;
    int selected=0;
    QStringList files;
    reclamation E;
    QByteArray data;
    Arduino A;

};

#endif // MAINWINDOW_H
